package com.company;

import org.w3c.dom.Text;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Main {

    public static void main(String[] args) {

        Frame f = new Frame("mini AWT calculator");
        f.setSize(500, 500);
        f.setLayout(null);
        f.setVisible(true);

        Label l1 = new Label("enter first number");
        Label l2 = new Label("choose operation");
        Label l3 = new Label("enter second number");
        Label l4 = new Label("result is");
        l1.setBounds(10, 50, 300, 30);
        l2.setBounds(10, 100, 300, 30);
        l3.setBounds(10, 150, 300, 30);
        l4.setBounds(10, 250, 300, 30);
        f.add(l1);
        f.add(l2);
        f.add(l3);
        f.add(l4);
        l4.setBackground(Color.red);
        TextField tf1 = new TextField();
        tf1.setBounds(320, 50, 50, 30);
        f.add(tf1);
        Choice myChoice = new Choice();
        myChoice.add("+");
        myChoice.add("-");
        myChoice.add("*");
        myChoice.add("/");
        myChoice.setBackground(Color.red);
        myChoice.setBounds(320, 100, 50, 30);
        f.add(myChoice);
        TextField tf2 = new TextField();
        tf2.setBounds(320, 150, 50, 30);
        f.add(tf2);
        Button b = new Button("calculate");
        b.setBounds(320, 200, 150, 30);
        f.add(b);
        Label final_result = new Label();
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int first_number = Integer.parseInt(tf1.getText());
                int second_number = Integer.parseInt((tf2.getText()));
                String operation = myChoice.getSelectedItem();
                System.out.println("click");
                int result = 0;
                boolean error = false;
                if (operation.equals("+")){
                    result = first_number + second_number;
                } else if (operation.equals("-")){
                    result = first_number - second_number;
                } else if (operation.equals("*")){
                    result = first_number * second_number;
                } else {
                    if (first_number != 0 && second_number != 0) {
                        result = first_number / second_number;
                    } else error = true;
                }
                if (error == false){
                    final_result.setText("" + result);
                } else final_result.setText("Zero not allowed!");
                final_result.setBounds(320, 250, 150, 30);
                f.add(final_result);

            }
        });

        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                f.dispose();
            }
        });

    }
}
